package samplecode.sampleapp.sampletwidgitpublicintent;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class TwidgitPublicIntent extends Activity implements OnClickListener {
	
	private static final int TWIDGIT_REQUEST_CODE = 2564;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        ((Button)findViewById(R.id.tweet_button)).setOnClickListener(this);
        ((Button)findViewById(R.id.mention_button)).setOnClickListener(this);
        ((Button)findViewById(R.id.retweet_button)).setOnClickListener(this);
        ((Button)findViewById(R.id.message_button)).setOnClickListener(this);
    }

	public void onClick(View v) {
		switch(v.getId()) {
			case R.id.tweet_button:
				
				// Standard tweet
		        Intent tIntent = new Intent("com.disretrospect.twidgit.TWEET");
		        tIntent.putExtra("com.disretrospect.twidgit.extras.MESSAGE", "_message_in_here_");
		        try {
		        	this.startActivityForResult(tIntent, TWIDGIT_REQUEST_CODE);
		        } catch (ActivityNotFoundException e) {
		        	// If Twidgit is not installed
		        }
				
				break;
			case R.id.mention_button:
				
				// Mention
				Intent mIntent = new Intent("com.disretrospect.twidgit.MENTION");
				mIntent.putExtra("com.disretrospect.twidgit.extras.TO", "_username_to_xmention_");
				mIntent.putExtra("com.disretrospect.twidgit.extras.MESSAGE", "_message_in_here_");
				try {
					this.startActivityForResult(mIntent, TWIDGIT_REQUEST_CODE);
				} catch (ActivityNotFoundException e) {
					// If Twidgit is not installed
				}
				
				break;
			case R.id.retweet_button:
				
				// Retweet a tweet
				Intent rtIntent = new Intent("com.disretrospect.twidgit.RETWEET");
				rtIntent.putExtra("com.disretrospect.twidgit.extras.MESSAGE", "_message_in_here_");
				rtIntent.putExtra("com.disretrospect.twidgit.extras.VIA", "_original_author_of_tweet_name_");
				try {
					this.startActivityForResult(rtIntent, TWIDGIT_REQUEST_CODE);
				} catch (ActivityNotFoundException e) {
					// If Twidgit is not installed
				}
				
				break;
			case R.id.message_button:
				
				// Send DM
				Intent dmIntent = new Intent("com.disretrospect.twidgit.DIRECT_MESSAGE");
				dmIntent.putExtra("com.disretrospect.twidgit.extras.TO", "_username_to_send_dm_to_");
				dmIntent.putExtra("com.disretrospect.twidgit.extras.MESSAGE", "_message_in_here_");
				try {
					this.startActivityForResult(dmIntent, TWIDGIT_REQUEST_CODE);
				} catch (ActivityNotFoundException e) {
					// If Twidgit is not installed
				}
				
				break;
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		// Check result code
		if(resultCode == Activity.RESULT_OK) {
			// Check requestCode
			switch(requestCode) {
				case TWIDGIT_REQUEST_CODE:
					// Handle successful return
				break;
			}
		} else if(resultCode == Activity.RESULT_CANCELED){
			// Handle canceled activity
		}
	}
}